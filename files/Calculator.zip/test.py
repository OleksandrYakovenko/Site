import tkinter as tk
from tkinter import ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def plot_function():
    # Отримуємо введену функцію з поля
    function_text = entry.get()
    
    try:
        # Генеруємо значення x
        x = np.linspace(-10, 10, 400)
        
        # Обчислюємо y (використовуємо eval, але це небезпечно без перевірок!)
        y = eval(function_text, {'x': x, 'np': np})
        
        # Очищаємо попередній графік
        ax.clear()
        
        # Малюємо новий графік
        ax.plot(x, y, label=f"y = {function_text}")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.legend()
        ax.grid(True)
        
        # Оновлюємо полотно
        canvas.draw()
    except Exception as e:
        error_label.config(text=f"Помилка: {e}")

# Створюємо головне вікно Tkinter
root = tk.Tk()
root.title("Графік функції")

# Поле для введення функції (наприклад, "x**2", "np.sin(x)", "x**3 + 2*x")
entry_label = tk.Label(root, text="Введіть функцію (наприклад, x**2):")
entry_label.pack(pady=5)

entry = tk.Entry(root, width=30)
entry.pack(pady=5)
entry.insert(0, "x**2")  # Приклад за замовчуванням

# Кнопка для побудови графіка
plot_button = tk.Button(root, text="Побудувати графік", command=plot_function)
plot_button.pack(pady=5)

# Мітка для виведення помилок
error_label = tk.Label(root, text="", foreground="red")
error_label.pack(pady=5)

# Створюємо фігуру matplotlib
fig, ax = plt.subplots(figsize=(6, 4))
ax.grid(True)

# Додаємо полотно для графіка у Tkinter
canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(pady=10)

# Запускаємо головний цикл

if __name__ == "__main__":
    # Запускаємо головний цикл Tkinter
    root.mainloop()