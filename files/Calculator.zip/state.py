entry = None
round_n = 10