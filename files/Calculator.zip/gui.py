from tkinter import *
import math
from calculation import on_button_click
import state  # імпортуємо модуль стану

def create_gui(root):
    
    # Поле вводу
    frame_1 = Frame(root)
    frame_1.pack(fill='x')

    state.entry = Entry(frame_1, font=("Arial", 40), borderwidth=5, state='readonly', justify='right')
    state.entry.pack(fill='x', padx=10, pady=5)

    # Кнопки
    frame_2 = Frame(root)
    frame_2.pack(fill=BOTH, expand=True)

    def standart():
       # Очистка кнопок перед створенням нових
        for widget in frame_2.winfo_children():
            widget.destroy()
    
        # Скидання всіх налаштувань grid
        for i in range(frame_2.grid_size()[1]):  # Скидаємо rowconfigure
            frame_2.rowconfigure(i, weight=0)
        for j in range(frame_2.grid_size()[0]):  # Скидаємо columnconfigure
            frame_2.columnconfigure(j, weight=0)

        buttons = [
            '7', '8', '9', '÷', 'AC', '!', '√', 'sin(',
            '4', '5', '6', '×', '( )', '^', 'log(', 'cos(',
            '1', '2', '3', '-', '%', 'π', 'ln(', 'tan(',
            '0', '.', 'C', '+', '=', 'e', 'ɸ', 'cot(',
        ]

        columns = 8  # Фіксована кількість стовпців
        rows = 4     # Фіксована кількість рядків

        for i in range(rows):
            frame_2.rowconfigure(i, weight=1)
        for j in range(columns):
            frame_2.columnconfigure(j, weight=1)

        for idx, text in enumerate(buttons):
            row = idx // columns
            col = idx % columns
            button = Button(
                frame_2,
                width=400,
                height=4,
                font=('Arial', 20),
                text=text,
                command=lambda t=text: on_button_click(t)
            )
            button.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")

    def sceinstific():
        # Очистка кнопок перед створенням нових
        for widget in frame_2.winfo_children():
            widget.destroy()
    
        # Скидання всіх налаштувань grid
        for i in range(frame_2.grid_size()[1]):  # Скидаємо rowconfigure
            frame_2.rowconfigure(i, weight=0)
        for j in range(frame_2.grid_size()[0]):  # Скидаємо columnconfigure
            frame_2.columnconfigure(j, weight=0)

        buttons = [
            '7', '8', '9', '÷', 'AC', '!', '√', 'sin(',
            '4', '5', '6', '×', '( )', '^', 'log(', 'cos(',
            '1', '2', '3', '-', '%', 'π', 'ln(', 'tan(',
            '0', '.', 'C', '+', '=', 'e', 'ɸ', 'cot(',
        ]

        columns = 8  # Фіксована кількість стовпців
        rows = 4     # Фіксована кількість рядків

        for i in range(rows):
            frame_2.rowconfigure(i, weight=1)
        for j in range(columns):
            frame_2.columnconfigure(j, weight=1)

        for idx, text in enumerate(buttons):
            row = idx // columns
            col = idx % columns
            button = Button(
                frame_2,
                width=400,
                height=4,
                font=('Arial', 20),
                text=text,
                command=lambda t=text: on_button_click(t)
            )
            button.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")



    def grafic():
        pass

    def round():
        w = Toplevel()
        
        def on_entry_click(event):
            if entry.get() == placeholder_text:
                entry.delete(0, END)
                entry.config(fg='black')

        def on_focusout(event):
            if entry.get() == '':
                entry.insert(0, placeholder_text)
                entry.config(fg='grey')

        def save():
            if entry.get() == '':
                pass
            else:
                state.round_n = entry.get()
            w.destroy()
        
        placeholder_text = "Введіть кількість знаків після коми при розрахунку"
        entry = Entry(w, fg='grey', font=("Arial", 10))
        entry.insert(0, placeholder_text)
        entry.bind('<FocusIn>', on_entry_click)
        entry.bind('<FocusOut>', on_focusout)
        entry.pack(pady=5)

        Button(w, text='Зберегти', command= save).pack(pady=5)

        w.grab_set() # Заборонити взаємодію з іншими вікнами
        w.focus_set() # Встановити фокус на діалогове вікно
        w.wait_window() # Зачекати, поки вікно буде закрито

    # Меню
    mainmenu = Menu(root)

    calc_menu = Menu(mainmenu, tearoff=0)
    calc_menu.add_command(label="Стандартний", command=standart)
    calc_menu.add_command(label="Науковий", command=sceinstific)
    calc_menu.add_command(label="Графічний", command=grafic)
    mainmenu.add_cascade(label="Вид", menu=calc_menu)

    option_menu =  Menu(mainmenu, tearoff=0)
    option_menu.add_command(label="Кількість знаків після коми", command=round)
    mainmenu.add_cascade(label="Налаштування", menu=option_menu)

    root.config(menu=mainmenu)

    standart()  # Виклик функції для створення кнопок стандартного калькулятора


   