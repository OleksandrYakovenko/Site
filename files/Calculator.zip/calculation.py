import re
import math
import state  # використовуємо спільну змінну entry
from tkinter import *

def on_key_press(event):
    entry = state.entry
    entry.configure(state='normal')
    if event.keysym == 'BackSpace':
        on_button_click('C')
    elif event.keysym == 'Return':
        on_button_click('=')
    elif event.keysym == 'Delete':
        on_button_click('AC')
    elif event.char in '0123456789+-*/()^%.,':
        on_button_click(event.char)
    entry.configure(state='readonly')

def on_button_click(text):
    entry = state.entry
    entry.configure(state='normal', disabledforeground='red')

    if text == '=':
        try:
            expression = prepare_expression(entry.get())
            result = eval(expression)
            entry.delete(0, END)
            entry.insert(0, str(round_result(result)))
        except Exception as e:
            entry.delete(0, END)
            entry.insert(0, 'Помилка')
            print(f'{e}')

    elif text == 'AC':
        entry.delete(0, END)
    elif text == 'C':
        entry.delete(len(entry.get()) - 1)
    elif text == '( )':
        if not entry.get() or entry.get()[-1] in '+-×÷(':
            entry.insert(END, '(')
        else:
            open_brackets = entry.get().count('(')
            close_brackets = entry.get().count(')')
            if open_brackets > close_brackets:
                entry.insert(END, ')')
            else:
                entry.insert(END, '(')
    else:
        if 'Помилка' in entry.get():
            entry.delete(0, END)
        text = text.replace('.', ',').replace('*', '×').replace('/', '÷')
        entry.insert(END, text)

    entry.configure(state='readonly')

def prepare_expression(expression):
    expression = expression.replace('^', '**')
    expression = expression.replace('%', '/100')
    expression = expression.replace('×', '*')
    expression = expression.replace('÷', '/')
    expression = expression.replace(',', '.')


    def replace_constant(match, constant):
        if match.group(1).isdigit():
            return match.group(1) + '*' + constant
        else:
            return match.group(1) + constant

    expression = re.sub(r'(\d*)e\b', lambda m: replace_constant(m, 'math.e'), expression)
    expression = re.sub(r'(\d*)π\b', lambda m: replace_constant(m, 'math.pi'), expression)
    expression = re.sub(r'(\d*)\bsin\(', lambda m: (m.group(1) + '*math.sin(math.radians(') if m.group(1) else 'math.sin(math.radians(', expression)
    expression = re.sub(r'(\d*)\bcos\(', lambda m: (m.group(1) + '*math.cos(math.radians(') if m.group(1) else 'math.cos(math.radians(', expression)
    expression = re.sub(r'(\d*)\btan\(', lambda m: (m.group(1) + '*math.tan(math.radians(') if m.group(1) else 'math.tan(math.radians(', expression)

    expression = re.sub(r'√(\d+)', r'math.sqrt(\1)', expression)
    

    expression = re.sub(r'(\d+)!', r'math.factorial(\1)', expression)
    expression = re.sub(r'\blog\(', 'math.log10(', expression)
    expression = re.sub(r'\bln\(', 'math.log(', expression)

    # Додавання відсутніх дужок
    open_brackets = expression.count('(')
    close_brackets = expression.count(')')
    if open_brackets > close_brackets:
        expression += ')' * (open_brackets - close_brackets)

    return expression

def round_result(value):
    if isinstance(value, float):
        value = round(value, int(state.round_n))
        if value.is_integer():
            value = int(value)
    return str(value).replace('.', ',')
