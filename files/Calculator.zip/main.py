from tkinter import *
from gui import create_gui
from calculation import on_key_press

if __name__ == "__main__":
    root = Tk()
    root.title("Calculator")
    root.geometry("400x400")
    root.minsize(400, 400) 
    create_gui(root)
    root.bind('<Key>', on_key_press)
    root.iconphoto(False, PhotoImage(file='icon.png'))
    root.mainloop()